cd "$(dirname "$0")"
SCRIPT_DIR="$(pwd)"
echo "Script directory: $SCRIPT_DIR"
cp -r $SCRIPT_DIR/files/. $HOME/pp/opt/app/